package com.sketchbot.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PointF
import android.net.Uri

object Tracer {

    class Result(val strokes: List<List<PointF>>, val w: Int, val h: Int, val preview: Bitmap)

    fun load(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (Math.max(o.outWidth, o.outHeight) / s > maxSide * 2) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, o2)
        } ?: return null
        val k = maxSide.toFloat() / Math.max(bmp.width, bmp.height)
        return if (k < 1f) Bitmap.createScaledBitmap(
            bmp,
            Math.max(1, (bmp.width * k).toInt()),
            Math.max(1, (bmp.height * k).toInt()),
            true
        ) else bmp
    }

    private fun grad(c: IntArray, i: Int, w: Int): Int {
        val gx = -c[i - w - 1] + c[i - w + 1] - 2 * c[i - 1] + 2 * c[i + 1] - c[i + w - 1] + c[i + w + 1]
        val gy = -c[i - w - 1] - 2 * c[i - w] - c[i - w + 1] + c[i + w - 1] + 2 * c[i + w] + c[i + w + 1]
        return Math.abs(gx) + Math.abs(gy)
    }

    /**
     * threshold: حد السواد للخطوط السوداء
     * detail: 0 = الخطوط السوداء فقط، وكلما زاد ظهرت حدود الألوان والتفاصيل الدقيقة
     */
    fun process(src: Bitmap, threshold: Int, detail: Int): Result {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val rr = IntArray(w * h)
        val gg = IntArray(w * h)
        val bb = IntArray(w * h)
        val lum = IntArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            if (Color.alpha(c) < 128) {
                rr[i] = 255; gg[i] = 255; bb[i] = 255; lum[i] = 255
            } else {
                rr[i] = Color.red(c); gg[i] = Color.green(c); bb[i] = Color.blue(c)
                lum[i] = (0.299 * rr[i] + 0.587 * gg[i] + 0.114 * bb[i]).toInt()
            }
        }

        val dark = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            dark[i] = lum[i] < threshold
        }

        val mask = dark.copyOf()
        if (detail > 0) {
            val t = 120 - detail
            val rad = 4
            for (y in rad until h - rad) {
                for (x in rad until w - rad) {
                    val i = y * w + x
                    if (dark[i]) continue
                    val m = Math.max(grad(rr, i, w), Math.max(grad(gg, i, w), grad(bb, i, w))) / 4
                    if (m <= t) continue
                    var near = false
                    var yy = -rad
                    while (yy <= rad && !near) {
                        var xx = -rad
                        while (xx <= rad) {
                            if (dark[i + yy * w + xx]) { near = true; break }
                            xx++
                        }
                        yy++
                    }
                    if (!near) mask[i] = true
                }
            }
        }

        thin(mask, w, h)
        val strokes = trace(mask, w, h)

        val out = IntArray(w * h) { if (mask[it]) Color.BLACK else Color.WHITE }
        val prev = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        prev.setPixels(out, 0, w, 0, 0, w, h)
        return Result(strokes, w, h, prev)
    }

    // Zhang-Suen thinning
    private fun thin(img: BooleanArray, w: Int, h: Int) {
        val del = IntArray(w * h)
        var changed = true
        while (changed) {
            changed = false
            for (step in 0..1) {
                var cnt = 0
                for (y in 1 until h - 1) {
                    for (x in 1 until w - 1) {
                        val i = y * w + x
                        if (!img[i]) continue
                        val p2 = img[i - w]
                        val p3 = img[i - w + 1]
                        val p4 = img[i + 1]
                        val p5 = img[i + w + 1]
                        val p6 = img[i + w]
                        val p7 = img[i + w - 1]
                        val p8 = img[i - 1]
                        val p9 = img[i - w - 1]
                        var n = 0
                        if (p2) n++
                        if (p3) n++
                        if (p4) n++
                        if (p5) n++
                        if (p6) n++
                        if (p7) n++
                        if (p8) n++
                        if (p9) n++
                        if (n < 2 || n > 6) continue
                        var a = 0
                        if (!p2 && p3) a++
                        if (!p3 && p4) a++
                        if (!p4 && p5) a++
                        if (!p5 && p6) a++
                        if (!p6 && p7) a++
                        if (!p7 && p8) a++
                        if (!p8 && p9) a++
                        if (!p9 && p2) a++
                        if (a != 1) continue
                        if (step == 0) {
                            if (p2 && p4 && p6) continue
                            if (p4 && p6 && p8) continue
                        } else {
                            if (p2 && p4 && p8) continue
                            if (p2 && p6 && p8) continue
                        }
                        del[cnt++] = i
                    }
                }
                if (cnt > 0) {
                    changed = true
                    for (k in 0 until cnt) img[del[k]] = false
                }
            }
        }
    }

    private val dxs = intArrayOf(1, -1, 0, 0, 1, 1, -1, -1)
    private val dys = intArrayOf(0, 0, 1, -1, 1, -1, 1, -1)

    private fun trace(sk: BooleanArray, w: Int, h: Int): List<List<PointF>> {
        val visited = BooleanArray(w * h)
        val out = ArrayList<List<PointF>>()
        val step = 2
        val minPts = 12

        fun neighborCount(i: Int): Int {
            val x = i % w
            val y = i / w
            var n = 0
            for (k in 0 until 8) {
                val nx = x + dxs[k]
                val ny = y + dys[k]
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                if (sk[ny * w + nx]) n++
            }
            return n
        }

        fun walk(start: Int) {
            val pts = ArrayList<Int>()
            var cur = start
            while (true) {
                visited[cur] = true
                pts.add(cur)
                val cx = cur % w
                val cy = cur / w
                var next = -1
                for (k in 0 until 8) {
                    val nx = cx + dxs[k]
                    val ny = cy + dys[k]
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val ni = ny * w + nx
                    if (sk[ni] && !visited[ni]) { next = ni; break }
                }
                if (next < 0) break
                cur = next
            }
            if (pts.size < minPts) return
            val res = ArrayList<PointF>()
            var k = 0
            while (k < pts.size) {
                res.add(PointF(pts[k] % w + 0.5f, pts[k] / w + 0.5f))
                k += step
            }
            if ((pts.size - 1) % step != 0) {
                val l = pts[pts.size - 1]
                res.add(PointF(l % w + 0.5f, l / w + 0.5f))
            }
            if (res.size >= 2) out.add(res)
        }

        for (i in sk.indices) if (sk[i] && !visited[i] && neighborCount(i) <= 1) walk(i)
        for (i in sk.indices) if (sk[i] && !visited[i]) walk(i)
        return out
    }
}
