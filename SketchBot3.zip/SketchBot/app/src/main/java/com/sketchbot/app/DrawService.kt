package com.sketchbot.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class DrawService : AccessibilityService() {

    companion object { var instance: DrawService? = null }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var wm: WindowManager? = null
    private var panel: View? = null
    private var calib: View? = null
    private var rect: RectF? = null

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        loadRect()
        showPanel()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { panel?.let { wm?.removeView(it) } } catch (_: Exception) {}
        try { calib?.let { wm?.removeView(it) } } catch (_: Exception) {}
        panel = null
        calib = null
        instance = null
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun overlayParams(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
    )

    // ---------- الحفظ ----------
    private fun loadRect() {
        val p = getSharedPreferences("sb", Context.MODE_PRIVATE)
        if (p.contains("l")) {
            rect = RectF(p.getFloat("l", 0f), p.getFloat("t", 0f), p.getFloat("r", 0f), p.getFloat("b", 0f))
        }
    }

    private fun saveRect(r: RectF) {
        getSharedPreferences("sb", Context.MODE_PRIVATE).edit()
            .putFloat("l", r.left).putFloat("t", r.top).putFloat("r", r.right).putFloat("b", r.bottom).apply()
    }

    // ---------- الشريط العائم ----------
    private fun showPanel() {
        val w = wm ?: return
        val d = resources.displayMetrics.density
        fun tv(t: String) = TextView(this@DrawService).apply {
            text = t
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
        }
        val handle = tv("☰")
        val bStart = tv("▶ ابدأ")
        val bStop = tv("■ إيقاف")
        val bCal = tv("⛶ الكانفس")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xDD222222.toInt())
            addView(handle); addView(bStart); addView(bStop); addView(bCal)
        }
        val lp = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (8 * d).toInt()
            y = (240 * d).toInt()
        }

        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - dx).toInt()
                    lp.y = sy + (e.rawY - dy).toInt()
                    try { w.updateViewLayout(root, lp) } catch (_: Exception) {}
                }
            }
            true
        }
        bStart.setOnClickListener { startDrawing() }
        bStop.setOnClickListener { stop(); toast("تم الإيقاف") }
        bCal.setOnClickListener { calibrate() }

        w.addView(root, lp)
        panel = root
    }

    // ---------- تحديد الكانفس ----------
    private class CalibView(ctx: Context) : View(ctx) {
        var a: PointF? = null
        var b: PointF? = null
        private val p = Paint().apply {
            color = 0xFFFF4081.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f
        }
        override fun onDraw(c: Canvas) {
            c.drawColor(0x33000000)
            val pa = a
            val pb = b
            if (pa != null) c.drawCircle(pa.x, pa.y, 20f, p)
            if (pa != null && pb != null) c.drawRect(pa.x, pa.y, pb.x, pb.y, p)
        }
    }

    private fun calibrate() {
        val w = wm ?: return
        if (calib != null) return
        val v = CalibView(this)
        val lp = overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                if (v.a == null) {
                    v.a = PointF(e.rawX, e.rawY)
                    v.invalidate()
                    toast("الآن اضغط الزاوية السفلية اليمنى")
                } else if (v.b == null) {
                    v.b = PointF(e.rawX, e.rawY)
                    val a = v.a!!
                    val r = RectF(
                        Math.min(a.x, e.rawX), Math.min(a.y, e.rawY),
                        Math.max(a.x, e.rawX), Math.max(a.y, e.rawY)
                    )
                    v.invalidate()
                    if (r.width() < 150f || r.height() < 150f) {
                        toast("الكانفس صغير جداً، أعد المحاولة")
                    } else {
                        rect = r
                        saveRect(r)
                        toast("تم حفظ الكانفس")
                    }
                    handler.postDelayed({
                        try { w.removeView(v) } catch (_: Exception) {}
                        calib = null
                    }, 1200)
                }
            }
            true
        }
        w.addView(v, lp)
        calib = v
        toast("اضغط الزاوية العليا اليسرى للكانفس")
    }

    // ---------- الرسم ----------
    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun startDrawing() {
        val r = rect
        val src = Shared.strokes
        if (src.isEmpty()) { toast("اختر صورة من التطبيق أولاً"); return }
        if (r == null) { toast("حدّد الكانفس أولاً"); return }
        if (running) return
        val s = Math.min(r.width() / Shared.imgW, r.height() / Shared.imgH)
        val ox = r.left + (r.width() - Shared.imgW * s) / 2f
        val oy = r.top + (r.height() - Shared.imgH * s) / 2f
        val mapped = src.map { st -> st.map { PointF(ox + it.x * s, oy + it.y * s) } }
        val ordered = order(mapped)
        running = true
        toast("سيبدأ الرسم بعد ثانيتين")
        handler.postDelayed({ drawNext(ordered, 0) }, 2000)
    }

    private fun order(list: List<List<PointF>>): List<List<PointF>> {
        val rem = list.toMutableList()
        val out = ArrayList<List<PointF>>()
        var cx = 0f
        var cy = 0f
        while (rem.isNotEmpty()) {
            var best = -1
            var bd = Float.MAX_VALUE
            var rev = false
            for (i in rem.indices) {
                val a = rem[i].first()
                val b = rem[i].last()
                val da = (a.x - cx) * (a.x - cx) + (a.y - cy) * (a.y - cy)
                val db = (b.x - cx) * (b.x - cx) + (b.y - cy) * (b.y - cy)
                if (da < bd) { bd = da; best = i; rev = false }
                if (db < bd) { bd = db; best = i; rev = true }
            }
            val st = rem.removeAt(best)
            val o = if (rev) st.reversed() else st
            out.add(o)
            cx = o.last().x
            cy = o.last().y
        }
        return out
    }

    private fun drawNext(strokes: List<List<PointF>>, i: Int) {
        if (!running) return
        if (i >= strokes.size) {
            running = false
            toast("انتهى الرسم")
            return
        }
        val pts = strokes[i].map {
            PointF(it.x + Random.nextFloat() * 3f - 1.5f, it.y + Random.nextFloat() * 3f - 1.5f)
        }
        if (pts.size < 2) { drawNext(strokes, i + 1); return }

        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        var len = 0f
        for (k in 1 until pts.size) {
            val dx = pts[k].x - pts[k - 1].x
            val dy = pts[k].y - pts[k - 1].y
            len += Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        }
        for (k in 1 until pts.size - 1) {
            path.quadTo(pts[k].x, pts[k].y, (pts[k].x + pts[k + 1].x) / 2f, (pts[k].y + pts[k + 1].y) / 2f)
        }
        path.lineTo(pts.last().x, pts.last().y)

        val speed = 0.4f + Random.nextFloat() * 0.8f
        val duration = (len / speed).toLong().coerceIn(120L, 4000L)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()

        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                val pause = if (Random.nextInt(12) == 0) Random.nextLong(1500, 3500)
                else Random.nextLong(100, 500)
                handler.postDelayed({ drawNext(strokes, i + 1) }, pause)
            }
            override fun onCancelled(g: GestureDescription?) { running = false }
        }, null)
        if (!ok) running = false
    }
}
